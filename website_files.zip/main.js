document.addEventListener("DOMContentLoaded", function () {
    // -----------------------------------
    // Hamburger Toggle Functionality with Icon Animation
    // -----------------------------------
    const hamburgerButton = document.querySelector('.hamburger a');
    const menu = document.getElementById('menu');
    const hamburgerIcon = document.querySelector('.hamburger-icon'); // Target the full hamburger icon

    if (hamburgerButton && menu && hamburgerIcon) {
        hamburgerButton.addEventListener('click', function (event) {
            event.preventDefault();
            menu.classList.toggle('active');  // Toggle menu visibility

            // Toggle the active class for the icon animation
            hamburgerIcon.classList.toggle('active');
        });
    }

    // -----------------------------------
    // Search Toggle Functionality
    // -----------------------------------
    const searchButton = document.querySelector('.search a');
    const searchForm = document.getElementById('search');

    if (searchButton && searchForm) {
        searchButton.addEventListener('click', function (event) {
            event.preventDefault();
            searchForm.classList.toggle('visible');  // Toggle search form visibility
        });
    }

    // -----------------------------------
    // Lightbox Functionality
    // -----------------------------------
    const lightbox = document.querySelector("#lightbox");
    const lightboxImage = document.querySelector("#lightbox-image");
    const lightboxTitle = document.querySelector("#lightbox-title");
    const lightboxDescription = document.querySelector("#lightbox-description");
    const lightboxPrev = document.querySelector("#lightbox-prev");
    const lightboxNext = document.querySelector("#lightbox-next");
    const lightboxClose = document.querySelector("#lightbox-close");
    const portfolioItems = document.querySelectorAll(".portfolio-item");

    let images = [];
    let titles = [];
    let descriptions = [];
    let currentIndex = -1;

    portfolioItems.forEach(item => {
        let imageSrc = item.querySelector("img").getAttribute("src");
        let titleElement = item.querySelector(".portfolio-overlay h3");
        let descriptionElement = item.querySelector(".portfolio-overlay p");
        let title = titleElement ? titleElement.textContent : "";
        let description = descriptionElement ? descriptionElement.textContent : "";
        images.push(imageSrc);
        titles.push(title);
        descriptions.push(description);
    });

    function updateLightboxContent() {
        lightboxImage.src = images[currentIndex];
        lightboxTitle.textContent = titles[currentIndex];
        lightboxDescription.textContent = descriptions[currentIndex];
    }

    if (lightbox && lightboxImage && portfolioItems.length > 0) {
        portfolioItems.forEach((item, index) => {
            item.addEventListener("click", function (event) {
                event.preventDefault();
                currentIndex = index;
                updateLightboxContent();
                lightbox.classList.add("active");
            });
        });

        lightbox.addEventListener("click", function (e) {
            if (e.target === lightbox) {
                lightbox.classList.remove("active");
            }
        });
    }

    if (lightboxClose) {
        lightboxClose.addEventListener("click", function () {
            lightbox.classList.remove("active");
        });
    }

    if (lightboxPrev && lightboxNext) {
        lightboxPrev.addEventListener("click", function () {
            currentIndex = (currentIndex - 1 + images.length) % images.length;
            updateLightboxContent();
        });

        lightboxNext.addEventListener("click", function () {
            currentIndex = (currentIndex + 1) % images.length;
            updateLightboxContent();
        });
    }

    // -----------------------------------
    // Parallax Effect
    // -----------------------------------
    const parallaxElement = document.querySelector('.parallax-background');
    if (parallaxElement) {
        window.addEventListener('scroll', function () {
            let offset = window.scrollY || window.pageYOffset || document.documentElement.scrollTop;
            parallaxElement.style.transform = 'translateY(' + offset * 0.5 + 'px)';
        });
    }

    // -----------------------------------
    // Filter Toggle and Filtering
    // -----------------------------------
    const filterToggleButton = document.querySelector('.filter-toggle');
    const filtersContainer = document.querySelector('.portfolio-filters');

    if (filterToggleButton && filtersContainer) {
        filterToggleButton.addEventListener("click", function () {
            filtersContainer.classList.toggle('active');
            filterToggleButton.textContent = filtersContainer.classList.contains('active') ? "Hide Filters" : "Show Filters";
        });
    }

    const filterButtons = document.querySelectorAll(".filter-btn");
    if (filterButtons.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener("click", function () {
                const category = button.getAttribute("data-filter");

                filterButtons.forEach(btn => btn.classList.remove("active"));
                button.classList.add("active");

                const portfolioItems = document.querySelectorAll(".portfolio-item");
                portfolioItems.forEach(item => {
                    item.style.display = (category === "*" || item.classList.contains(category.substring(1))) ? "block" : "none";
                });
            });
        });
    }

    // -----------------------------------
    // Smooth Scroll Functionality
    // -----------------------------------
    const smoothScrollLinks = document.querySelectorAll('a[href^="#"]:not(.menu a)');
    smoothScrollLinks.forEach(link => {
        link.addEventListener("click", function (event) {
            event.preventDefault();
            const targetId = this.getAttribute("href").substring(1);
            const targetElement = document.getElementById(targetId);

            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: "smooth"
                });
            }
        });
    });

    const logoLink = document.querySelector('h1 a');
    if (logoLink) {
        logoLink.addEventListener("click", function (event) {
            event.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        });
    }
});
